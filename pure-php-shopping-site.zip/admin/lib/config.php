<?php 
error_reporting(E_ALL);// Report all errors
//error_reporting(E_ALL & ~E_NOTICE);// Report all errors except E_NOTICE
$base_url = 'http://app.ecims-binny-traders.test/admin/'; //base URL
?>
