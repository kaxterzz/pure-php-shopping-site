<div class="container-fluid page-footer">
  <div class="panel-footer">
    <div style="color:#068"><center><small>Copyright &copy; 2015 Binny Traders All rights reserved</small></center></div>
  </div>
</div>