<?php 
$msg="Dear Customer,\n\n";
	mail("newuser@localhost","Mail from ABC",$msg);
	echo("sent...");
?>