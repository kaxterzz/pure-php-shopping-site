<?php
include('../lib/config.php'); // attach config.php
include('../lib/connection.php'); // attach db connection
$meta_title = "Monthly Sales Report";
session_start();
include('../inc-head.php');//attach inc-head.php
$fromDate=$_POST['monthlylysales_from'];
$toDate=$_POST['monthlylysales_to'];
$frommonth=date('m',strtotime($fromDate));// extract month
$fromyear=date('Y',strtotime($fromDate)); //extract year
$tomonth=date('m',strtotime($toDate));// extract month
$toyear=date('Y',strtotime($toDate)); //extract year
$fromnewmonth=''; //month to display on title
$tonewmonth=''; //month to display on title
	switch($frommonth){
		case 1:
		  $fromnewmonth= "January";
		  break;
		case 2:
		  $fromnewmonth= "February";
		  break;
		case 3:
		  $fromnewmonth= "March";
		  break;
		case 4:
		  $fromnewmonth= "April";
		  break;
		case 5:
		  $fromnewmonth= "May";
		  break;
		case 6:
		  $fromnewmonth= "June";
		  break;
		case 7:
		  $fromnewmonth= "July";
		  break;
		case 8:
		  $fromnewmonth= "August";
		  break;
		case 9:
		  $fromnewmonth= "September";
		  break;
		case 10:
		  $fromnewmonth= "October";
		  break;
		case 11:
		  $fromnewmonth= "November";
		  break;
		case 12:
		  $fromnewmonth= "December";
		  break;
		default:
		  $fromnewmonth='Incorrect month selection';
	  } 

	  switch($tomonth){
		case 1:
		  $tonewmonth= "January";
		  break;
		case 2:
		  $tonewmonth= "February";
		  break;
		case 3:
		  $tonewmonth= "March";
		  break;
		case 4:
		  $tonewmonth= "April";
		  break;
		case 5:
		  $tonewmonth= "May";
		  break;
		case 6:
		  $tonewmonth= "June";
		  break;
		case 7:
		  $tonewmonth= "July";
		  break;
		case 8:
		  $tonewmonth= "August";
		  break;
		case 9:
		  $tonewmonth= "September";
		  break;
		case 10:
		  $tonewmonth= "October";
		  break;
		case 11:
		  $tonewmonth= "November";
		  break;
		case 12:
		  $tonewmonth= "December";
		  break;
		default:
		  $tonewmonth='Incorrect month selection';
	  } 

?>
</head>

<body>
	<div class="container-fluid">
    	<div id="upper-bannar">
        	<table class="table table-condensed">
            	<tr>
                	<th rowspan="4"  class="col-md-1">
               		 	<img class="img-responsive" src="../images/logo1.png" width="75%"/>
                    </th>    
                    
                </tr>
                <tr>
                	
                	<td class="col-md-10" style="padding-bottom:0px;border-top:0px"><h1 style="margin:0px;color:#2E8AE6;font-family:Georgia, 'Times New Roman', Times, serif;">AMAYA FASHION</h1></td>
                </tr>
                <tr>
                	
                	<td style="border-top:0px;padding:0px 0px 0px;font-size:16px">No.720, Rajamaha Vihara Mw, Kelaniya</td>	 
                </tr>
                <tr>
                	
                	<td style="border-top:0px;padding:0px 0px 0px;font-size:16px">Tel.No: +94 773 518787</td>
                </tr>
            </table>
            <hr>
        </div><!-- upper-bannar-->
        <div class="container">
        	<div id="topic">
            	<h4>From&nbsp;<?php echo $fromnewmonth?>&nbsp;<?php echo $fromyear ?>&nbsp;To<?php echo $tonewmonth?>&nbsp;<?php echo $toyear ?>&nbsp;Sales Report</h4>
            </div>
        	<table class="table table-bordered tblreports"  style="border-color:#000">
            	<thead>
                <tr>
                <th class="col-md-1">No</th>
                <th class="col-md-6">Date</th>
                <th class="col-md-5">Sales Amount(Rs)</th>
                </tr>
                </thead>
                <tbody id="monthly_sales_details">
                <?php 
					$sql="SELECT DATE(inv_date),inv_ntot,SUM(inv_ntot) FROM tbl_invoice WHERE MONTH(inv_date) BETWEEN '$frommonth' AND '$tomonth' AND YEAR(inv_date) BETWEEN '$fromyear' AND '$toyear' GROUP BY inv_date;";
					$res=mysqli_query($GLOBALS['conn'],$sql) or die("SQL Error:".mysqli_error($GLOBALS['conn']));
					$nor=mysqli_num_rows($res);
					$i=1;
					$ntot=0;
					if($nor>0){	
						while($row=mysqli_fetch_assoc($res)){
							?>
							<tr>
                            	<td class="col-md-1" style="text-align:center">
								<?php if($i<=$nor){
										echo $i;
										$i++;
									}?></td>
                                <td class="col-md-6" style="text-align:center"><?php echo $row['DATE(inv_date)'] ?></td>
                                <td class="col-md-5" style="text-align:right"><?php echo number_format((double)$row['inv_ntot'],2,'.',',')?></td>
                            </tr>
                            
					<?php	
						$ntot=(double)((double)$ntot+$row['SUM(inv_ntot)']);// get the summesion of all netsales
						
						}	//end while
					}//end if
					elseif($nor==0){
						echo '<tr><td colspan="4"><center>No Records found</center></td></tr>';	
					}
				?>
                </tbody>
                <tfoot>
                	<tr>
                    	<th colspan="2" style="text-align:right">Total Sales</th>
                        <th id="totsal" style="text-align:right"><?php echo number_format($ntot,2,'.',',');?></th>
                    </tr>
                </tfoot>
            </table>
             <div class="container printbar">
            	<button id="btnprint" name="btnprint" class="btn btn-warning pull-right"><span class="glyphicon glyphicon-print"></span> Print</button>
            </div>
        </div><!-- end container -->
    </div><!-- cantainer-fluid-->
    <?php include('../inc-footer.php'); ?>
</body>
</html>
<script type="text/javascript">
	 $("#btnprint").click(function(){				
			  $(this).hide();
			  window.print();
			  $(this).show();
		  });
</script>